Dette var et prosjekt jeg brukte ca. 5 måneder på i 2021. Her lærte jeg mye om OOP, konstruktorer og instansiering.
Koden er fremdeles veldig rotete, og nettsiden er ikke dynamisk (proporsjonaliteten er ikke riktig når man endrer størrelse på siden)
Fortsatt et prosjekt jeg er veldig stolt over og definitivt det prosjektet der jeg lærte mest.